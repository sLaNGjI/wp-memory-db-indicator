=== Memory Load db Usage ===
Contributors: sLaNGjI
Donate link: http://slangji.wordpress.com/donate/
Tags: max, memory, load, db, size, usage, footer, dashboard, admin, bar, toolbar, slangji 
Stable tag: 2012.1125.0000
Requires at least: 3.1
Tested up to: 3.5
License: GPLv2 or later
Indicate Memory Load Consumption and db size Usage on WordPress Backend. Show Memory Load and db size on Footer, and Max Memory Load on Admin Bar or ToolBar.
== Description ==
Website: [slangji.wordpress.com](http://slangji.wordpress.com/)

Display the PHP Memory Load Consuption and db Usage on Dashboard Footer, and Backend Admin Bar or ToolBar. This is usefull when you've got limited PHP memory available, or limited db quote, and are trying to keep track on how much you've got left.

This Plugin is Based and Derived Directly from Almost Famous [WP Overview (lite)](http://wordpress.org/extend/plugins/wp-overview-lite/).

Compatible with Single and Network MultiSite Environment.

Work under [GPLv2](http://www.gnu.org/licenses/gpl-2.0.html) License.

* Try also:
 * [WP Overview (lite)](http://wordpress.org/extend/plugins/wp-overview-lite/)
 * [WP Missed Schedule](http://wordpress.org/extend/plugins/wp-missed-schedule/)
 * [WP Admin Bar Removal](http://wordpress.org/extend/plugins/wp-admin-bar-removal/) Linked and reviewed at [softpedia.com](http://webscripts.softpedia.com/script/Modules/WordPress-Plugins/Admin-Bar-Removal-completely-disable-73547.html)
 * [WP Admin Bar Node Removal](http://wordpress.org/extend/plugins/wp-admin-bar-node-removal/)
 * [WP Toolbar Removal](http://wordpress.org/extend/plugins/wp-toolbar-removal/) Linked and reviewed at [softpedia.com](http://webscripts.softpedia.com/script/Modules/WordPress-Plugins/ToolBar-Removal-completely-disable-73548.html)
 * [WP Toolbar Node Removal](http://wordpress.org/extend/plugins/wp-toolbar-node-removal/)
 * [Noindex (login) WordPress Deindexing](http://wordpress.org/extend/plugins/wp-login-deindexing/)
 * [Noindex (total) WordPress Deindexing](http://wordpress.org/extend/plugins/wp-total-deindexing/)
 * [IE Enhancer and Modernizer](http://wordpress.org/extend/plugins/wp-ie-enhancer-and-modernizer/) Linked and reviewed at [softpedia.com](http://webscripts.softpedia.com/script/Modules/WordPress-Plugins/IE-Enhancer-and-Modernizer-73546.html)

Author URL [sLa](http://wordpress.org/extend/plugins/profile/sla) is moved to [sLaNGjI](http://wordpress.org/extend/plugins/profile/slangji). Please update your bookmarks!
== Changelog ==
`All previous release, prior of latest stable, are on fact
deprecated, and no longer supported on this project:
is very suggested upgrade to the latest build always!
This plugin work under GPLv2 license.`
= Development Release =
[Version 2013 Build 0000-BUGFIX Revision 0000-DEVELOPMENT](http://downloads.wordpress.org/plugin/wp-memory-db-usage.zip)
= 2012.1125.0000 =
* Release [STABLE] Show Memory Load and db size Usage on WordPress Backend.
 * First Plugin Release
 * Work under GPLv2 license
 * Bump Version 2012 Build 1125 Revision 0000
== Upgrade Notice ==
= 2012.1125.0000 =
* Release [STABLE] Show Memory Load and db size Usage on WordPress Backend. Work under GPLv2 license.